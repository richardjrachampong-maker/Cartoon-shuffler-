// Runs on showshuffle.live. Tells the site the extension is installed and
// relays the TV playlist (a list of legal episode URLs) to the extension.
(function () {
  const VERSION = '1.0.0';
  function announce() {
    try { document.documentElement.setAttribute('data-ss-ext', VERSION); } catch (e) {}
    window.postMessage({ type: 'SS_EXT_READY', version: VERSION }, '*');
  }
  announce();
  document.addEventListener('DOMContentLoaded', announce);
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || typeof ev.data !== 'object') return;
    if (ev.data.type === 'SS_PLAYLIST' && Array.isArray(ev.data.items)) {
      chrome.runtime.sendMessage({ type: 'SET_PLAYLIST', items: ev.data.items.slice(0, 200), label: ev.data.label || 'Show Shuffler TV', current: ev.data.current || null }, (r) => {
        window.postMessage({ type: 'SS_PLAYLIST_ACK', count: (r && r.count) || 0 }, '*');
      });
    }
    if (ev.data.type === 'SS_PING') announce();
  });
})();
