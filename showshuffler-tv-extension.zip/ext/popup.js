chrome.runtime.sendMessage({ type: 'STATE' }, (s) => {
  if (!s) return;
  document.getElementById('count').textContent = s.items.length;
  document.getElementById('label').textContent = s.label ? 'Now on: ' + s.label : 'Not tuned in.';
  document.getElementById('played').textContent = s.played ? s.played + ' played this session' : '';
});
document.getElementById('clear').addEventListener('click', () => chrome.runtime.sendMessage({ type: 'CLEAR' }, () => location.reload()));
