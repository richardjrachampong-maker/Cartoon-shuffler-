// Runs on streaming sites. Reads the REAL player: duration + position from the
// page's <video>. When the episode ends, shows "Up next … Cancel" for 12s, then
// moves this tab to the next Show Shuffler pick (any service). If nothing is
// queued it taps the site's own Next button. If a site hides its <video>, it
// falls back to the episode's runtime.
(function () {
  if (window.top !== window) { /* iframes: still hook video, no overlay */ }
  if (window.__ssPlayerHooked) return; window.__ssPlayerHooked = true;
  const hooked = new WeakSet(); let fired = false, overlay = null, sawVideo = false;
  const NEXT_SELECTORS = [
    '[data-uia="next-episode-seamless-button"]', '[data-uia="next-episode-seamless-button-draining"]',
    'button[aria-label*="Next episode" i]', 'button[aria-label*="Next Episode" i]', 'button[aria-label*="Play next" i]',
    '[data-testid*="next" i]', 'button[title*="Next" i]'
  ];
  function clickNative() { for (const s of NEXT_SELECTORS) { const b = document.querySelector(s); if (b) { b.click(); return true; } } return false; }
  function serviceName() {
    const h = location.hostname;
    if (/netflix/.test(h)) return 'Netflix'; if (/disney/.test(h)) return 'Disney+'; if (/hulu/.test(h)) return 'Hulu';
    if (/tubi/.test(h)) return 'Tubi'; if (/pluto/.test(h)) return 'Pluto TV'; if (/roku/.test(h)) return 'The Roku Channel';
    if (/max\.com/.test(h)) return 'Max'; if (/peacock/.test(h)) return 'Peacock'; return h;
  }
  function showOverlay(next) {
    if (overlay) overlay.remove();
    let secs = 12;
    overlay = document.createElement('div');
    overlay.setAttribute('style', 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:2147483647;background:rgba(10,10,10,.94);color:#fff;border:1px solid rgba(255,255,255,.14);border-radius:18px;padding:16px 18px;width:min(420px,92vw);font:14px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;box-shadow:0 20px 60px rgba(0,0,0,.6)');
    overlay.innerHTML =
      '<div style="font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#F5B544;font-weight:800;margin-bottom:6px">Show Shuffler · up next</div>' +
      '<div style="font-weight:700;font-size:15px;margin-bottom:2px">' + esc(next.title) + '</div>' +
      '<div style="color:#bbb;margin-bottom:12px">Taking you to <b style="color:#fff">' + esc(next.service || 'the next episode') + '</b> in <span id="ss-secs">' + secs + '</span>s</div>' +
      '<div style="display:flex;gap:8px"><button id="ss-go" style="flex:1;border:0;border-radius:10px;padding:10px;font-weight:800;background:linear-gradient(135deg,#F5B544,#FF7A59);color:#1b1300;cursor:pointer">Play now</button>' +
      '<button id="ss-cancel" style="flex:1;border:1px solid rgba(255,255,255,.18);border-radius:10px;padding:10px;font-weight:700;background:transparent;color:#fff;cursor:pointer">Cancel</button></div>';
    document.documentElement.appendChild(overlay);
    const tick = setInterval(() => { secs--; const e = overlay && overlay.querySelector('#ss-secs'); if (e) e.textContent = secs; if (secs <= 0) go(); }, 1000);
    function go() { clearInterval(tick); if (overlay) { overlay.remove(); overlay = null; } chrome.runtime.sendMessage({ type: 'ADVANCE' }); }
    function cancel() { clearInterval(tick); if (overlay) { overlay.remove(); overlay = null; } chrome.runtime.sendMessage({ type: 'CANCEL' }); }
    overlay.querySelector('#ss-go').addEventListener('click', go);
    overlay.querySelector('#ss-cancel').addEventListener('click', cancel);
  }
  function esc(s) { return String(s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function onEnded() {
    if (fired) return; fired = true;
    setTimeout(() => { fired = false; }, 20000);
    chrome.runtime.sendMessage({ type: 'NEXT_PREVIEW' }, (r) => {
      if (r && r.next && window.top === window) showOverlay(r.next);
      else if (!r || !r.next) setTimeout(clickNative, 1500);
    });
  }
  function hook(v) {
    if (!v || hooked.has(v)) return; hooked.add(v); sawVideo = true;
    v.addEventListener('ended', onEnded);
    v.addEventListener('timeupdate', () => { if (v.duration && v.duration > 120 && v.currentTime >= v.duration - 1.5) onEnded(); });
  }
  function scan() { document.querySelectorAll('video').forEach(hook); }
  scan();
  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });
  setInterval(scan, 3000);
  // Runtime fallback: no readable <video> after 30s -> use the episode length we were given.
  if (window.top === window) setTimeout(() => {
    if (sawVideo) return;
    chrome.runtime.sendMessage({ type: 'STATE' }, (st) => {
      const mins = st && st.current && st.current.mins;
      if (mins) setTimeout(onEnded, Math.max(5, mins) * 60 * 1000);
    });
  }, 30000);
})();
