// Keeps the queue. Player tabs ask what's next (preview), then advance after
// the countdown — the tab simply navigates to the next legal page.
async function getState() {
  const s = await chrome.storage.local.get(['items', 'label', 'played', 'current']);
  return { items: s.items || [], label: s.label || '', played: s.played || 0, current: s.current || null };
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === 'SET_PLAYLIST') {
      await chrome.storage.local.set({ items: msg.items, label: msg.label, played: 0, current: msg.current || null });
      sendResponse({ count: msg.items.length }); return;
    }
    if (msg.type === 'NEXT_PREVIEW') { const st = await getState(); sendResponse({ next: st.items[0] || null, current: st.current }); return; }
    if (msg.type === 'ADVANCE') {
      const st = await getState();
      const next = st.items.shift();
      if (next && sender.tab && sender.tab.id != null) {
        await chrome.storage.local.set({ items: st.items, played: st.played + 1, current: next });
        chrome.tabs.update(sender.tab.id, { url: next.url });
        sendResponse({ ok: true, next });
      } else sendResponse({ ok: false });
      return;
    }
    if (msg.type === 'STATE') { sendResponse(await getState()); return; }
    if (msg.type === 'CLEAR' || msg.type === 'CANCEL') { await chrome.storage.local.set({ items: [], played: 0, current: null }); sendResponse({ ok: true }); return; }
  })();
  return true;
});
